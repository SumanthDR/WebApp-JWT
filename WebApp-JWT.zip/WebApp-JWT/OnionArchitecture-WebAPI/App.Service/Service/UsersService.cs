﻿using App.Model.Data;
using App.Model.RequestModel;
using App.Model.RequestModel.Users;
using App.Repository.IRepository;
using App.Service.IService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.Service.Service
{
    public class UsersService : IUsersService
    {
        private readonly IUsersRepository _IusersRepository;

        public UsersService(IUsersRepository IUsersRepository)
        {
            _IusersRepository = IUsersRepository;
        }

        public async Task<Users> AddUserAsync(AddUsersRequestModel addUsersRequestModel)
        {
            var result = await _IusersRepository.AddUserAsync(addUsersRequestModel);
            return result;
        }

        public async Task<List<UsersListResponseModel>> GetListOfUsersAsync()
        {
            var result = await _IusersRepository.GetListOfUsersAsync();
            return result;
        }

        public async Task<Users> GetUserByIdAsync(int id)
        {
            var result = await _IusersRepository.GetUserByIdAsync(id);
            return result;
        }

        public async Task<bool> DeleteUserByIdAsync(int id)
        {
            var result = await _IusersRepository.DeleteUserByIdAsync(id);
            return result;
        }

        public async Task<Users> UpdateUserDetailsAsync(UpdateUserRequestModel updateUserRequestModel)
        {
            var result = await _IusersRepository.UpdateUserDetailsAsync(updateUserRequestModel);
            return result;
        }
    }
}
