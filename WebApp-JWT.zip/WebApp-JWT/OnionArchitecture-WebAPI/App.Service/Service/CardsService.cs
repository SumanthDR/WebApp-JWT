﻿using App.Model.Data;
using App.Model.RequestModel.Cards;
using App.Repository.IRepository;
using App.Service.IService;

namespace App.Service.Service
{
    public class CardsService : ICardsService
    {
        private readonly ICardsRespository _IcardsRespository;
        public CardsService(ICardsRespository IcardsRespository)
        {
            _IcardsRespository = IcardsRespository;
        }

        public async Task<Cards> AddCardsAsync(AddCardsRequestModel addCardsRequestModel)
        {
            var result = await _IcardsRespository.AddCardsAsync(addCardsRequestModel);
            return result;
        }

        public async Task<List<Cards>> GetListOfCardsAsync()
        {
            var result = await _IcardsRespository.GetListOfCardsAsync();
            return result;
        }

        public async Task<Cards> GetCardByIdAsync(int id)
        {
            var result = await _IcardsRespository.GetCardByIdAsync(id);
            return result;
        }

        public async Task<bool> DeleteCardByIdAsync(int id)
        {
            var result = await _IcardsRespository.DeleteCardByIdAsync(id);
            return result;
        }

        public async Task<Cards> UpdateCardDetailsAsync(UpdateCardsRequestModel updateCardsRequestModel)
        {
            var result = await _IcardsRespository.UpdateCardDetailsAsync(updateCardsRequestModel);
            return result;
        }
    }
}
