﻿using App.Model;
using App.Model.Data;
using App.Model.RequestModel;
using App.Model.RequestModel.Cards;
using App.Model.RequestModel.Users;
using App.Repository.IRepository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.Repository.Repository
{
    public class UsersRepository : IUsersRepository
    {
        private readonly AppDbContext _appDbContext;
        public UsersRepository(AppDbContext appDbContext)
        {
               _appDbContext = appDbContext;
        }
        
        public async Task<Users> AddUserAsync(AddUsersRequestModel addUsersRequestModel)
        {
            Users users = new Users
            {
                Name = addUsersRequestModel.Name,
                Gender = addUsersRequestModel.Gender,
                CardsId = addUsersRequestModel.CardsId,
                DOB = addUsersRequestModel.DOB,                
                CreatedDateTime = DateTime.Now,
                IsActive = true
            };

            _appDbContext.Users.Add(users);
            await _appDbContext.SaveChangesAsync();

            return users;
        }

        public async Task<List<UsersListResponseModel>> GetListOfUsersAsync()
        {
            List<UsersListResponseModel> users = await _appDbContext.Users
                                                                    .Include(x => x.Cards)
                                                                    .Where(x => x.IsActive)
                                                                    .Select(x => new UsersListResponseModel
                                                                    {
                                                                        Id = x.Id,
                                                                        Name = x.Name,
                                                                        Gender = x.Gender,
                                                                        CardsId = x.CardsId,
                                                                        CardName = x.Cards.Name,
                                                                        DOB = x.DOB,
                                                                        CreatedDateTime = x.CreatedDateTime,
                                                                        UpdatedDateTime = x.UpdatedDateTime
                                                                    })
                                                                    .ToListAsync();
            return users;
        }

        public async Task<Users> GetUserByIdAsync(int id)
        {
            var user = await _appDbContext.Users.FirstOrDefaultAsync(x => x.Id == id && x.IsActive);
            return user;
        }

        public async Task<bool> DeleteUserByIdAsync(int id)
        {
            Users user = await GetUserByIdAsync(id);
            if (user is not  null)
            {
                user.IsActive = false;
                user.UpdatedDateTime = DateTime.Now;
                _appDbContext.Users.Update(user);
                await _appDbContext.SaveChangesAsync();

                return true;
            }
            return false;
        }

        public async Task<Users> UpdateUserDetailsAsync(UpdateUserRequestModel updateUserRequestModel)
        {
            var result = await GetUserByIdAsync(updateUserRequestModel.Id);

            if (result != null)
            {
                result.Name = updateUserRequestModel.Name;
                result.Gender = updateUserRequestModel.Gender;
                result.CardsId = updateUserRequestModel.CardsId;
                result.DOB = updateUserRequestModel.DOB;
                result.UpdatedDateTime =  DateTime.Now;

                _appDbContext.Users.Update(result);
                await _appDbContext.SaveChangesAsync();
            }
            return result;
        }
    }
}
