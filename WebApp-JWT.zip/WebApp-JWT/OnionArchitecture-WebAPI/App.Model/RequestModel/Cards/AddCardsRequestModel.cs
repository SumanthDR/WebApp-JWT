﻿namespace App.Model.RequestModel.Cards
{
    public class AddCardsRequestModel
    {        
        public string Name { get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDateTime { get; set; }
    }
}
