﻿using App.Model.RequestModel.Cards;
using App.Service.IService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace App.Web.Controllers.Cards
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class CardsController : Controller
    {
        private readonly ICardsService _ICardsService;
        
        public CardsController(ICardsService IcardsService)
        {
            _ICardsService = IcardsService;
        }
        
        [HttpPost("AddCards")]
        public async Task<IActionResult> AddCards(AddCardsRequestModel addCardsRequestModel)
        {
            var result = await _ICardsService.AddCardsAsync(addCardsRequestModel);
            return Ok(result);
        }

        [HttpGet("GetListOfCards")]
        public async Task<IActionResult> GetListOfCards()
        {
            var result = await _ICardsService.GetListOfCardsAsync();
            return Ok(result);
        }

        [HttpGet("GetCardById")]
        public async Task<IActionResult> GetCardByIdAsync(int id)
        {
            var result = await _ICardsService.GetCardByIdAsync(id);
            return Ok(result);
        }

        [HttpPut("DeleteCardById")]
        public async Task<IActionResult> DeleteCardByIdAsync(int id)
        {
            var result = await _ICardsService.DeleteCardByIdAsync(id);
            return Ok(result);
        }

        [HttpPut("UpdateCardDetails")]
        public async Task<IActionResult> UpdateCardDetailsAsync(UpdateCardsRequestModel updateCardsRequestModel)
        {
            var result = await _ICardsService.UpdateCardDetailsAsync(updateCardsRequestModel);
            return Ok(result);
        }
    }
}
