﻿using App.Model;
using App.Model.RequestModel.Auth;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace App.Web.Controllers.Auth
{
    [ApiController]
    [Route("api/[controller]")]
    public class LoginController : ControllerBase
    {
        private readonly TokenService _tokenService;
        public LoginController(TokenService tokenService)
        {
            _tokenService = tokenService;
        }

        [HttpPost("Login")]
        public async Task<IActionResult> Login(User user)
        {
            if (user.UserName.Equals("admin") && user.Password.Equals("admin"))
            {
                var generatedToken = await _tokenService.GenerateTokenAsync(user.UserName);
                var token = new Token
                {
                    AccessToken = generatedToken,
                    Message = "Success"
                };
                return Ok(token);
            }
            var invalidToken = new Token
            {
                AccessToken = string.Empty,
                Message = "Invalid UserName or Password"
            };
            return Ok(invalidToken);
        }
    }
}
