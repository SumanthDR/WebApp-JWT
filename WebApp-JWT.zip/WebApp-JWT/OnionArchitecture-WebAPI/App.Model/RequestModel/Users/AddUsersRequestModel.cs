﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.Model.RequestModel.Users
{
    public class AddUsersRequestModel
    {
        public string Name { get; set; }
        public char Gender { get; set; }
        public DateTime DOB { get; set; }
        public int CardsId { get; set; }        
    }
}
